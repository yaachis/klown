package com.androidatc.klown

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.CompoundButton
import android.widget.CompoundButton.OnCheckedChangeListener
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SwitchCompat
import kotlinx.android.synthetic.main.activity_settings.*

class Settings : AppCompatActivity() {

    private lateinit var btn: SwitchCompat

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        btn = findViewById(R.id.darkMdeBtn)
        val sharedPreferences = getSharedPreferences(
            "sp", MODE_PRIVATE
        )

        val editor = sharedPreferences.edit()
        val isDarkMode = sharedPreferences.getBoolean(
            "isDarkModeOn", false
        )

        if(isDarkMode){
            goInDarkMode()
            btn.isChecked = true
        }

        btn.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                goInDarkMode()
                editor.putBoolean("isDarkModeOn",true)
                editor.apply()
            } else {
                goInLightMode()
                editor.putBoolean("isDarkModeOn",false)
                editor.apply()
            }
        }
    }

    private fun goInDarkMode(){
        AppCompatDelegate
            .setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
    }

private fun  goInLightMode(){
    AppCompatDelegate
        .setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
}
}