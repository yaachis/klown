package com.androidatc.klown

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_thanks.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        lateinit var slider: SeekBar
        lateinit var value: TextView

        //This is the Shirt SeekBar part:D
        slider=myShirtBar
        value=myShirtSize
        val shirtSize= arrayListOf<String>("Please Select","Small","Medium","Large","Xtra-Large")

        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {

                value.text=shirtSize[progress]

            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {

            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {

            }
        })

        placeorderBtn.setOnClickListener {
            var intent = Intent(this, Thanks::class.java)
            intent.putExtra("name", myFullName.text.toString())
            intent.putExtra("phoneNumber", myPhoneNumber.text.toString())
            intent.putExtra("shirtSize", myShirtSize.text.toString())
            intent.putExtra("city", myCity.text.toString())
            intent.putExtra("state", myState.text.toString())
            intent.putExtra("country", myCountry.text.toString())
            startActivity(intent)
        }
        settingsBtn.setOnClickListener {
            var intent = Intent(this, Settings::class.java)

            startActivity(intent)
        }
        helpBtn.setOnClickListener {
            var intent = Intent(this, Help::class.java)

            startActivity(intent)
        }

    }
}